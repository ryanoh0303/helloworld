public class Square extends Rectangle{

    public Square(){
        super();
    }

    public Square(String name, String color, int numSides, double sideLen){
        super(name, color, numSides, sideLen, sideLen);

    }

    //Where are the functions??
    //Welp, there are no need to implement them, since they are already in the
    //superclass. I guess that works out.


    //turns out this class is completely pointless. Oops!


}
